describe("Mutator 1", () => {
	it("should work", () => {
		chai.expect(2).to.equal(2);
	});
});