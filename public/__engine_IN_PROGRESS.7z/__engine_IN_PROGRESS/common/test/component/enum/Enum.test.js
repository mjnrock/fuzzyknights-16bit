describe("Enum 1", () => {
	it("should break", () => {
		chai.expect(5).to.equal(3);
	});
});