import "./component/element/Elements.test.js";
import "./component/enum/Enum.test.js";
import "./component/mutator/Mutator.test.js";