import D2 from "./d2/package.js";

export default {
	D2
};