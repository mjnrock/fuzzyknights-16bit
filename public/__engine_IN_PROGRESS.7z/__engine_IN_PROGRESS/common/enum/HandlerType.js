export default {
	PLAYER:		1,
	INPUT: 		2,
	ENTITY:		3,
	KEY:		4
};