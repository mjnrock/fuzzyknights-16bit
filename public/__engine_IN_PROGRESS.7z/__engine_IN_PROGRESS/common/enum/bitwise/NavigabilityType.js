export default {
	NONE:		1 << 0,
	WATER:		1 << 1,
	GRASS:		1 << 2,
	DIRT:		1 << 3,
	PATH:		1 << 4,
	ROCK:		1 << 5,
	SAND:		1 << 6
};