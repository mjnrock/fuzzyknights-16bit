class Realm {
	constructor() {}
}

export default Realm;