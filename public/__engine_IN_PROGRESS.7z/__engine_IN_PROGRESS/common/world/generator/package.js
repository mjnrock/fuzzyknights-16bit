import Zone from "./Zone.js";
import Realm from "./Realm.js";

export default {
	Zone,
	Realm
};