class Zone {
	constructor() {}
}

export default Zone;