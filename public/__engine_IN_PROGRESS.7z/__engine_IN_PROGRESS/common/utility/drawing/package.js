import Canvas from "./Canvas.js";

export default {
	Canvas
};