import { Creature } from "./Creature.js";
import { Raccoon } from "./Raccoon.js";
import { Beaver } from "./Beaver.js";

export default {
	Creature,
	Raccoon,
	Beaver
};